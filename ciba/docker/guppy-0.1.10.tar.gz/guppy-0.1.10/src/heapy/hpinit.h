int fsb_dx_addmethods(PyObject *m, PyMethodDef *methods, PyObject *passthrough);

